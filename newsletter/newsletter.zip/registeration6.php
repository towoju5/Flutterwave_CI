<?php $message .= '<div style=\"width: 600px; background: #FFFFFF; margin: 0 auto; border-radius: 10px; box-shadow: 0 0 5px #ccc; border: 1px solid #DA7CAF;\">
<div style=\"background: #f7f7f7; padding: 10px; border-radius: 10px 10px 0 0; text-align: center;\"><a href=\"'.base_url().'\" target=\"_blank\"><img style=\"margin: 5px 20px 0px 0px;\" src=\"'.base_url().'images/logo/'.$logo_image.'\" border=\"0\" alt=\"'.$title.'\" width=\"205\" /> </a></div>
<div style=\"background: #fff; padding: 10px; width: 580px;\">
<div style=\"font-family: Myriad Pro; font-size: 24px; color: #da7caf; padding-bottom: 15px; font-weight: bold;\">'.$news_subject.'</div>
<div style=\"font-family: Myriad Pro; font-size: 16px; color: #000; padding-bottom: 15px; line-height: 24px; text-align: justify;\">'.$news_descrip.'</div>
<div style=\"font-family: Myriad Pro; font-size: 16px; color: #000; padding-bottom: 15px; line-height: 24px; text-align: justify;\">If you have any questions please email <a style=\"color: #5ea008; text-decoration: none;\" href=\"/cdn-cgi/l/email-protection#c2b9e6b6aaabb1efe4a5b6f9a1adaca4aba5efe4a5b6f9abb6a7afeae5a7afa3abaee5ebbf\">'.$email.'</a></div>
<div style=\"font-family: Myriad Pro; font-size: 18px; color: #000; padding-bottom: 15px; line-height: 28px;\">Sincerely , <br /> Management</div>
</div>
</div>';  ?>
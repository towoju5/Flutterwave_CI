<?php $message .= '<table class=\"ui-sortable-handle currentTable\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"100%\" align=\"center\" bgcolor=\"#4f595b\">
<tbody>
<tr>
<td>
<table class=\"devicewidth\" style=\"border: 0px solid #f5fafb; width: 600px; background-color: #ecfafd;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" align=\"center\">
<tbody>
<tr>
<td height=\"30\" bgcolor=\"#4f595b\">&nbsp;</td>
</tr>
<tr>
<td align=\"left\" bgcolor=\"#4f595b\"><img src=\"'.base_url().'images/logo/'.$logo.'\" alt=\"logo\" /></td>
</tr>
<tr>
<td height=\"30\" bgcolor=\"#4f595b\">&nbsp;</td>
</tr>
<tr>
<td class=\"editable\" align=\"center\" valign=\"middle\">HI ADMIN</td>
</tr>
<tr>
<td height=\"30\">&nbsp;</td>
</tr>
<tr>
<td align=\"center\">You have created a new listing with your Cudlstay account on '.$cdate.' at '.$ctime.'.</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align=\"left\">List name : '.$propertyname.'</td>
</tr>
<tr>
<td align=\"left\">Link : '.base_url().'rental/'.$propertyid.'</td>
</tr>
<tr>
<td align=\"left\">Price : $ '.$price.'</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align=\"left\">If this not you, you can ignore this email.</td>
</tr>
<tr>
<td>&nbsp;</td>
</tr>
<tr>
<td align=\"left\">If this wasn\'t you, let us know. Notifying us is important because it helps us make sure no one is accessing your account without your knowledge.</td>
</tr>
<tr>
<td height=\"30\">&nbsp;</td>
</tr>
<tr>
<td align=\"left\" valign=\"middle\">
<p>Thanks!</p>
<p>The <span> VacationHosting </span> Team</p>
</td>
</tr>
<tr>
<td height=\"30\">&nbsp;</td>
</tr>
<tr>
<td height=\"30\" bgcolor=\"#4f595b\">&nbsp;</td>
</tr>
<tr>
<td align=\"center\" bgcolor=\"#4f595b\">&nbsp;</td>
</tr>
<tr>
<td height=\"50\" bgcolor=\"#4f595b\">&nbsp;<br /><br /></td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>';  ?>
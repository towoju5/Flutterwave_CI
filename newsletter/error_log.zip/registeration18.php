<?php $message .= '<div style=\"display: inline-block; background: none repeat scroll 0px 0px #f7f7f7; border: medium none; box-shadow: 0px 0px 2px 0px #cccccc; color: #565a5c; line-height: 21px; width: 560px; padding: 20px 50px;\">
<div style=\"display: inline-block; text-align: center; width: 100%;\"><img style=\"width: 149px;\" src=\"'.base_url().'images/logo/'.$logo.'\" alt=\"\" /></div>
<div style=\"display: inline-block; font-size: 13px; width: 100%; margin: 0; padding: 0; font-family: Helvetica,Arial,sans-serif;\"><span>Hi</span><label style=\"padding: 0 0 0 2px;\">'.$username.',</label>
<div style=\"display: inline-block; width: 100%; margin: 0px; font-family: Helvetica,Arial,sans-serif; font-size: 14px; padding: 9px 0px 6px;\">Thanks for choosing to verify your ID. Our team will contact you soon once email id has been verified.</div>
<div class=\"p \" style=\"padding: 0px; font-family: Helvetica,Arial,sans-serif; font-size: 14px; margin: 1em 0px 3em;\">Thanks,<br style=\"margin: 0; padding: 0;\" />The '.$email_title.' Team</div>
</div>
</div>';  ?>
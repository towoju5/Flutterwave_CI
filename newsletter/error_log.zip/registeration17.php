<?php $message .= '<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"640\" bgcolor=\"#7da2c1\">
<tbody>
<tr>
<td style=\"padding: 40px;\">
<table style=\"border: #1d4567 1px solid; font-family: Arial, Helvetica, sans-serif;\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" width=\"610\">
<tbody>
<tr>
<td><a href=\"'.base_url().'\"><img style=\"margin: 15px 5px 0; padding: 0px; border: none;\" src=\"'.base_url().'images/logo/'.$logo_image.'\" alt=\"'.$meta_title.'\" /></a></td>
</tr>
<tr>
<td valign=\"top\">
<table border=\"0\" cellspacing=\"0\" cellpadding=\"0\" bgcolor=\"#FFFFFF\">
<tbody>
<tr>
<td colspan=\"2\">
<h3 style=\"padding: 10px 15px; margin: 0px; color: #0d487a;\">Hi</h3>
</td>
<td>&nbsp;</td>
</tr>
<tr>
<td style=\"font-size: 12px; padding: 10px 15px;\" width=\"50%\" valign=\"top\">
<p>'.$message_content.'</p>
</td>
<td style=\"font-size: 12px; padding: 10px 15px;\" width=\"50%\" valign=\"top\">
<p>&nbsp;</p>
<p><strong>- '.$email_title.' Team</strong></p>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
</tbody>
</table>';  ?>